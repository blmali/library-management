from django.contrib import admin
from .models import Student,Book

admin.site.register(Student)
admin.site.register(Book)
